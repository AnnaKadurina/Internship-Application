package getawaygo_project.getawaygo_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GetawayGoBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}

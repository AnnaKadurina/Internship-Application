package getawaygo_project.getawaygo_backend.business;

public interface DeleteReviewUseCase {
    void deleteReview(long reviewId);

}

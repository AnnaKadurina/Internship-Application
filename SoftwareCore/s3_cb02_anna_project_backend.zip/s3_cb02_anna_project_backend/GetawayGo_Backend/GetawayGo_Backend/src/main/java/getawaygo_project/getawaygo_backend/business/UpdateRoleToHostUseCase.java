package getawaygo_project.getawaygo_backend.business;

public interface UpdateRoleToHostUseCase {
    void updateRole(long id);

}

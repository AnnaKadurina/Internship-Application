package getawaygo_project.getawaygo_backend.business;

import getawaygo_project.getawaygo_backend.domain.GetAllUsersResponse;

public interface GetAllUsersUseCase {
GetAllUsersResponse getUsers();
}

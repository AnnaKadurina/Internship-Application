package getawaygo_project.getawaygo_backend.business;

import getawaygo_project.getawaygo_backend.domain.UpdateUserRequest;

public interface UpdateUserUseCase {
void updateUser(UpdateUserRequest updateUserRequest);
}

package getawaygo_project.getawaygo_backend.business;

import getawaygo_project.getawaygo_backend.domain.UpdatePropertyRequest;

public interface UpdatePropertyUseCase {
    void updateProperty(UpdatePropertyRequest updatePropertyRequest);
}

package getawaygo_project.getawaygo_backend.domain;

public enum Status {
    JOIN,
    MESSAGE,
    LEAVE
}

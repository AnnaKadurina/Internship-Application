package getawaygo_project.getawaygo_backend.business;

public interface GenerateBookingFileUseCase {
    String generateFile(long id);
}

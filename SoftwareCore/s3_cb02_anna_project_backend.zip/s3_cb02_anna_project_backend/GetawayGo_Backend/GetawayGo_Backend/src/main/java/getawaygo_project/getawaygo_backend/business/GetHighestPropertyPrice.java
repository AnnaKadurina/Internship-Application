package getawaygo_project.getawaygo_backend.business;

public interface GetHighestPropertyPrice {
    Double getHighestPropertyPrice();
}

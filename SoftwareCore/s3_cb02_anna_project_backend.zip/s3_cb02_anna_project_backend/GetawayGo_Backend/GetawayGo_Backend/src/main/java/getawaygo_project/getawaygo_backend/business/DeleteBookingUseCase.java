package getawaygo_project.getawaygo_backend.business;

public interface DeleteBookingUseCase {
    void deleteBooking(long bookingId);
}

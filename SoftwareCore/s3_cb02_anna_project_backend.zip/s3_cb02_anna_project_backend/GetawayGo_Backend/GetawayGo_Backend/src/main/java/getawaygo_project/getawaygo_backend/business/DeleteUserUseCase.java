package getawaygo_project.getawaygo_backend.business;

public interface DeleteUserUseCase {
    void deleteUser(long userId);
}

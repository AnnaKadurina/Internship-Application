const GOOGLE_API_KEY = "AIzaSyBfj-oZ0ut0h3eNlXvX8WabaTZ-t0QF2Nc";

export default GOOGLE_API_KEY;
